# -*- coding: utf-8 -*-
"""
Created on Wed Nov 24 00:40:48 2021

@author: Laura and Alessia
"""

from load_measurements import *
from aggregate_measurements import aggregate_measurements
from print_statistics import print_statistics
from plot_data import plot_data
from helpFunctions import *

#MAIN SCRIPT

# Lists five possibilities the user can choose between
menuItems = ["Load data","Aggregate data", "Display statistics", "Visualize electricity consumption", "Quit"]

# Lists ways of aggregate the data between which you can choose
wayOfAggregation = ["Minute --> no aggregation","hour", "day", "month", 'hour of the day']

# List of way to plot data
VisualizeItems = ["each zone", "all zones"]


#Flags
dataLoaded = False
dataAggregated = False

period = 1 #if period == 0 then data is not aggregated

while True:
    menuHeader("\nMAIN MENU", wayOfAggregation[int(period)-1])
    mainMenu = displayMenu(menuItems);
    
    if mainMenu == 1: 
        menuHeader("\nLOAD DATA", wayOfAggregation[int(period)-1])
        active = True
        
        # asks user for filename till they enter a correct one 
        # or choose to go back
        while active: 
            filename = input("To get back to Main Menu write 'back' or\nenter filename to load data from: ")
            
            if filename ==  'back': # user chose not to load data
                print("\nYou chose to go back to MainMenu")
                active = False
                
            elif not checkFilename(filename):
                print("\nEntered filename does not exist")
                
            else: #prompts user to choose fmode if file is correct
                fmodeChoices = ["forward fill", "backward fill", "drop"]
                print("Choose a method to deal with corrupted data")
                fmode = displayMenu(fmodeChoices)
                tvec, data = load_measurements(filename, fmodeChoices[int(fmode)-1])
                originalData = data
                originaltvec = tvec
                active = False
                dataLoaded = True
                print("File '"+filename+"' has been loaded")
                
    #Aggregate data
    elif mainMenu == 2:
        menuHeader("\nAGGREGATE DATA", wayOfAggregation[int(period)-1])
        period = displayMenu(wayOfAggregation)
        if (dataLoaded):
            if (dataAggregated and period == 1 ):
                data = originalData
                tvec = originaltvec
                dataAggregated = False
                print("The original data has been restored")
            else:
                if (period == 1):
                    continue;
                else:
                    tvec, data = aggregate_measurements(tvec, data, wayOfAggregation[int(period)-1])
                    print('You have now aggregated your data according to this period: ', wayOfAggregation[int(period)-1])
        else:
            print("Please upload your data first")
            
    #Display statistics
    elif mainMenu == 3:
        menuHeader("\nDISPLAY STATISTICS", wayOfAggregation[int(period)-1])
        if (dataLoaded):
            print_statistics( tvec, data)
        else:
            print("Please upload your data first")
    #Visualize            
    elif mainMenu == 4:
        menuHeader("\nVISUALIZE ELECTRICITY CONSUMPTION", wayOfAggregation[int(period)-1])
        if (dataLoaded):
            zone = displayMenu(VisualizeItems)
            plot_data(tvec, data,VisualizeItems[int( zone)-1], wayOfAggregation[int(period)-1])
            print("Data are aggregated based by the period ", wayOfAggregation[int(period)-1], 'and plotted by ', VisualizeItems[int(zone)-1])
        else:
            print("Please upload your data first") 
    #Quits the program: 
    elif mainMenu == 5:
        print("\nYou have choosen to quit, goodbye!")
        
        break

        
                
            
            
        