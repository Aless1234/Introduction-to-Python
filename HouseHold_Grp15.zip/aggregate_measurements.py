# -*- coding: utf-8 -*-
"""
Created on Thu Dec  2 16:12:52 2021

@author: Alessia
"""


import numpy as np
import pandas as pd

#Function that aggregate data based on period
def aggregate_measurements(tvec, data, period):
    df_join = tvec.join(data)
    
    
    #Aggregate measurements by month:
    if period == 'month':
        df_agg = df_join.groupby(['year', 'month']).sum()
    
    #Aggregate measurements by day:
    elif period == 'day':
        df_agg = df_join.groupby(['year', 'month', 'day']).sum()
    
    #Aggregate measurements by hour:
    elif period == 'hour':
        df_agg = df_join.groupby(['year', 'month', 'day', 'hour']).sum()
        
    #Aggregate measurements by hourly mean:
    elif period == 'hour of the day':
        df_agg = df_join.groupby(['hour']).mean()
    
    #Resets index of dataframe:
    df_new = df_agg.reset_index()
    df_new = df_new[['year', 'month', 'day', 'hour', 'minute', 'second', 'zone1', 'zone2', 'zone3', 'zone4']]
    
    #Converts dataframe to 2 dataframes (Nx6 and Nx4):     
    tvec_df = df_new[['year', 'month', 'day', 'hour', 'minute', 'second']]
    data_df = df_new[['zone1', 'zone2', 'zone3', 'zone4']]
    
    #Converts dataframes to numpy arrays:
    #tvec_a = np.array(tvec_df.values)
    #data_a = np.array(data_df.values)
    
    #Saves matrices
    #np.save('df_agg', df_agg)
    #np.save('tvec_a', tvec_df)
    #np.save('data_a', data_df)
    
    
    return (tvec_df, data_df)
