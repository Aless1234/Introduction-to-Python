import os.path
from os import path
import numpy as np


def displayMenu(menuItems):
    print("\n")
    for i in range (np.shape(menuItems)[0]):
        print("[",(i+1),"]",menuItems[i])
    choice = inputNumber("Enter your option: ")
    
    if choice > len(menuItems) or choice < 0:
        print("\nChoosen number is out of menu range")
    return choice
    

# A function which checks if user input is a number 
# and returns an error if not
# Author: Mikkel N. Schmidt, mnsc@dtu.dk, 2015
def inputNumber(prompt):
       
    while True:
        try:
            num = float(input(prompt))
            break
        except ValueError:
            pass
            print("\nError in typing, please type again")
        
    
    return num

def menuHeader(currentMenu, aggregation):
    print(currentMenu)
    if aggregation == 'minute':
        aggregation = 'none'
        
    print("Applied aggregation:",aggregation)
            
def checkFilename(filename):
    if os.path.isfile('./'+filename):
       return True
   
    return False


        

    



        