# -*- coding: utf-8 -*-
"""
Created on Sun Nov 21 17:40:19 2021

@author: laura
"""
import pandas as pd
import numpy as np

def load_measurements(filename, fmode):
    dataHeader = ['year', 'month','day','hour','minute', 'second', 'zone1', 'zone2', 'zone3', 'zone4']
    df = pd.read_csv(filename, names = dataHeader) 

    df = df.replace(-1,np.NaN)

    if (df.iloc[0,:].isnull().any() or df.iloc[len(df)-1,:].isnull().any()) and fmode != 'drop':
        print("System was not able to eliminate corrupt lines with mode '"+fmode+"' .Instead 'drop' was used")
        fmode = 'drop'
        

    if fmode == 'forward fill':
        df = df.ffill()
        
    elif fmode == 'backward fill':
        df = df.bfill()
    
    elif fmode == 'drop':
        df = df.dropna()
    
    tvec = df.loc[:,'year':'second'] 
    data = df.loc[:,'zone1':'zone4']

    return tvec, data

