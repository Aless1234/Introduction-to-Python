# -*- coding: utf-8 -*-
"""
Created on Tue Nov 30 15:48:29 2021

@author: Alessia
"""

#Import modules:
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


#Function that plot aggregated data based on zone and period:
def plot_data(tvec_a, data_a, zone, period):
    
    
    sumAllZone_series = data_a.sum(axis=1)
    sumAllZone = pd.Series.to_frame(sumAllZone_series)
    sumAllZone.columns = ['All zone']
    num_aggregated_rows = len(sumAllZone)
    
    
    dataJoined = data_a.join(sumAllZone)
    
    
    #PLot if zone equals single zone:
    if zone == 'each zone':
        fig, ax = plt.subplots()
        
        ax.scatter(tvec_a[period], dataJoined["zone1"], label = "Zone 1" )
        ax.scatter(tvec_a[period], dataJoined["zone2"], label = "Zone 2" )
        ax.scatter(tvec_a[period], dataJoined["zone3"], label = "Zone 3" )
        ax.scatter(tvec_a[period], dataJoined["zone4"], label = "Zone 4" )
        
        ax.set_xlabel('Period ' + period)
        ax.set_ylabel('Electricity, Watt')
        ax.set_title('Electricity consumption per ' + period)

        ax.legend(loc=(1.05, 0.5))
        plt.tight_layout()
    
        plt.show()
            
    #Plot if zone equals all zones:
    
    elif zone == 'all zones':
        if (num_aggregated_rows> 25 ):   
            fig, ax = plt.subplots()
            ax.scatter(tvec_a[period],dataJoined["All zone"], label='All zones')
    
            ax.set_xlabel('Period ' + period)
            ax.set_ylabel('Electricity, Watt')
            ax.set_title('Electricity consumption per ' + period)
            ax.legend(loc=(1.05, 0.5))
            plt.tight_layout()
    
            plt.show()
        else:
            #if we have less then 25 rows then we plot a bar graph
            fig, ax = plt.subplots()
            ax.bar(tvec_a[period],dataJoined["All zone"], label='All zones')
            ax.set_xlabel('Period ' + period)
            ax.set_ylabel('Electricity, Watt')
            ax.set_title('Electricity consumption per ' + period)
            ax.legend(loc=(1.05, 0.5))
            plt.tight_layout()
    
            plt.show()
