# -*- coding: utf-8 -*-
"""
Created on Tue Nov 30 15:44:03 2021

@author: Soheil
"""

import numpy as np
import pandas as pd

def print_statistics(tvec, data):
    list1=[]
    list2=[]
    list3=[]
    list4=[]
    for row in data:
        list1=data.iloc[:,0] 
        list2=data.iloc[:,1]
        list3=data.iloc[:,2]
        list4=data.iloc[:,3]
#calculating min,Q1,Q2,Q3,max for Zone1
    zone_1=np.percentile(list1, [0,25, 50, 75,100]) 
    zone_2=np.percentile(list2, [0,25, 50, 75,100])
    zone_3=np.percentile(list3, [0,25, 50, 75,100])
    zone_4=np.percentile(list4, [0,25, 50, 75,100])
#Here they are being combined into one array
    table=[zone_1,zone_2,zone_3,zone_4] 
#we are adding titles for columns and presenting them as a DataFrame  
    df = pd.DataFrame(table, columns = ['Min','Q1','Q2','Q3','Max'])  
    Min_col=df.loc[:,'Min'] 
    Q1_col=df.loc[:,'Q1']
    Q2_col=df.loc[:,'Q2']
    Q3_col=df.loc[:,'Q3']
    Max_col=df.loc[:,'Max']
#Now we are adding a row of 0 values
    df = df.append(pd.Series(0, index=df.columns), ignore_index=True) 
    df.index = np.arange(1, len(df)+1) 
#index colum is named as zone
    df.index.names = ['Zone']
    df.loc[len(df)].at["Min"]=min(Min_col)
    df.loc[len(df)].at["Q1"]=np.percentile(Q1_col, 25)
    df.loc[len(df)].at["Q2"]=np.percentile(Q2_col, 50)
    df.loc[len(df)].at["Q3"]=np.percentile(Q3_col, 75)
    df.loc[len(df)].at["Max"]=max(Max_col)
    df= df.rename(index={5: 'All'})
    print(df)
    return